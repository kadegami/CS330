///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR:Karina Washington July 31st, 2023
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	//initilize the texture colleciton
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/



/***************************************************************/
/***** Function SceneManager LoadSceneTextures ****/
/*This method creates the set up of the texture but refering to
images file path pre-laoded to the "directory file path for"
/utilities/ textures once I added this method my keyboard.jpg
got load. Added Ausgust 2nd 2024*/ 

void SceneManager::LoadSceneTextures() { //NEW methods added for milestone 7_1 week 5 August 2
	bool bReturn = false;
	//Keaboard
	bReturn = CreateGLTexture(
		"../../Utilities/textures/keyboard.jpg",
		"keyboard"
	);

	//Monitor1 
	bReturn = CreateGLTexture(
		"../../Utilities/textures/monitor1.jpg",
		"monitor1"
	);

	//Monitor2 
	bReturn = CreateGLTexture(
		"../../Utilities/textures/monitor2.jpg",
		"monitor2"
	);

	//cupholder 

	bReturn = CreateGLTexture(
		"../../Utilities/textures/cupHolder.jpg",
		"woodenCupHolder"
	);


	//cup

	bReturn = CreateGLTexture(
		"../../Utilities/textures/cup.jpg",
		"cup"
	);

	//notebook 

	bReturn = CreateGLTexture(
		"../../Utilities/textures/notebook.jpg",
		"notebook"
	);

	//mouse 

	bReturn = CreateGLTexture(
		"../../Utilities/textures/mouse.jpg",
		"mouse"
	);

	BindGLTextures();
}

/*This method SceneManager defineObjectMaterials works 
to add or attach the picture to the shapes / This method is used for 
configuring the various material
settomg for all the objtes/items wihtin the 3D scene*/



void SceneManager::DefineObjectMaterials() { // August 2nd
	//Keyboard material
	OBJECT_MATERIAL keyboardMaterial;
	keyboardMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	keyboardMaterial.ambientStrength = 0.3f;
	keyboardMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	keyboardMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	keyboardMaterial.shininess = 22.0;
	keyboardMaterial.tag = "board";

	m_objectMaterials.push_back(keyboardMaterial);

	//Monitor 1 material

	OBJECT_MATERIAL monitor1Material;
	monitor1Material.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	monitor1Material.ambientStrength = 0.3f;
	monitor1Material.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	monitor1Material.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	monitor1Material.shininess = 22.0;
	monitor1Material.tag = "mon1";

	m_objectMaterials.push_back(monitor1Material);

	//monitor 2 material 

	OBJECT_MATERIAL monitor2Material;
	monitor2Material.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	monitor2Material.ambientStrength = 0.3f;
	monitor2Material.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	monitor2Material.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	monitor2Material.shininess = 22.0;
	monitor2Material.tag = "mon2";

	m_objectMaterials.push_back(monitor2Material);

	//cup holder material

	OBJECT_MATERIAL cupHolderMaterial;
	cupHolderMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	cupHolderMaterial.ambientStrength = 0.3f;
	cupHolderMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	cupHolderMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	cupHolderMaterial.shininess = 22.0;
	cupHolderMaterial.tag = "cupHolder";

	m_objectMaterials.push_back(cupHolderMaterial);


	//cup material

	OBJECT_MATERIAL cupMaterial;
	cupMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	cupMaterial.ambientStrength = 0.3f;
	cupMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	cupMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	cupMaterial.shininess = 22.0;
	cupMaterial.tag = "cup";

	m_objectMaterials.push_back(cupMaterial);


	//notebook

	OBJECT_MATERIAL notebookMaterial;
	notebookMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	notebookMaterial.ambientStrength = 0.3f;
	notebookMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	notebookMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	notebookMaterial.shininess = 22.0;
	notebookMaterial.tag = "notebook";

	m_objectMaterials.push_back(notebookMaterial);

	//mouse

	OBJECT_MATERIAL mouseMaterial;
	mouseMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	mouseMaterial.ambientStrength = 0.3f;
	mouseMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	mouseMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	mouseMaterial.shininess = 22.0;
	mouseMaterial.tag = "mouse";

	m_objectMaterials.push_back(mouseMaterial);


}



/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D sfcene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

//	CreateGLTexture(
	//	"../../Utilities/textures/keyboard.jpg",
		//"keyboard");

	LoadSceneTextures(); //added new function LoadScene...
	m_basicMeshes->LoadPlaneMesh(); //
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
}

//// ADD TEXTURE METHODS??? check OpenglSample

//Add lighting
/*************************************************************
* Lighting()
* 
* This method is used to set up the lighting in the scene
**************************************************************/

void SceneManager::Lighting()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	m_pShaderManager->setBoolValue(g_UseTextureName, false);

	//Left light
	m_pShaderManager->setVec3Value("lightSources[0].position", -30.0f, 40.0f, 10.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.01f, 0.01f, 0.01f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.1f);

	//Right light
	m_pShaderManager->setVec3Value("lightSources[1].position", 30.0f, 40.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.01f, 0.01f, 0.01f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.4f, 0.2f, 0.3f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.1f);


	// Center lighit
	m_pShaderManager->setVec3Value("lightSources[2].position", 0.0f, 30.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.5f, 0.5f, 0.5f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 1.2f, 0.6f, 0.8f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.5f, 0.5f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.8f);



	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, 3.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.6f, 0.3f, 0.4f);
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.2f);
}


//sfvoid SceneManager

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, -5.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0, 1.0, 1.0, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	/// Week 3 the creation of two monitors 


	/******************************/
	/**********MONITOR 2***********/
    // Render monitor 2 (bottom monitor)
	scaleXYZ = glm::vec3(8.0f, 4.5f, 0.9f);
	XrotationDegrees = 0.0f;
	XrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.0f, 0.0f, 0.0f);

	SetTransformations(

		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 0.0f, 0.0f, 0.9f);// red monitor screen

	//monitor2 render texture
	SetShaderTexture("monitor2");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("mon2"); // Added shadermaterials august 2nd 

	//Week 5 Adding textures .. 

	m_basicMeshes->DrawBoxMesh();

	/******************************/
	/**********MONITOR 1***********/
	//Render monitor 1 (top monitor)
	positionXYZ = glm::vec3(-4.0f, 5.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 0.0f, 0.0f, 1.0f);

	//monitor1 render texture
	SetShaderTexture("monitor1");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("mon1"); // Added shadermaterials august 2nd 

	m_basicMeshes->DrawBoxMesh();


	/******************************/
	/**********keyboard***********/
	//Render keyboard 

	scaleXYZ = glm::vec3(6.0f, 1.5f, 1.4f);
	positionXYZ = glm::vec3(-3.5f, -3.5f, 2.0f);

	XrotationDegrees = 30;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 0.0f, 1.0f);



	//Keayboard render texture 
	SetShaderTexture("keyboard");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("board"); // Added shadermaterials august 2nd 


	m_basicMeshes->DrawBoxMesh();

	/******************************/
	/**********Cup Holder ***********/
	//Render Cup Holder

	scaleXYZ = glm::vec3(1.3f, 0.7f, 1.3f);
	positionXYZ = glm::vec3(3.5f, -3.5f, -0.7f);
	XrotationDegrees = 0;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.0f, 0.0f, 1.0f, 1.0f);
	//Keayboard render texture 
	SetShaderTexture("woodenCupHolder");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("cupHolder"); // Added shadermaterials august 2nd 


	m_basicMeshes->DrawCylinderMesh();


	/******************************/
	/**********Cilindro***********/
	//Render cylinder


	//Render Cup

	scaleXYZ = glm::vec3(1.0f, 2.5f,-.10f);
	positionXYZ = glm::vec3(3.5f, -2.5f, -0.5f);

	XrotationDegrees = 0;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.5f, 0.0f, 0.5f, 1.0f);
	//Keayboard render texture 
	SetShaderTexture("cup");
	SetTextureUVScale(1, 1);
	SetShaderMaterial("cup"); // Added shadermaterials august 2nd 


	m_basicMeshes->DrawCylinderMesh();


	/******************************/
	/**********Notebook***********/
	//Render notebook


	scaleXYZ = glm::vec3(2.0f, 0.3f, 3.0f);
	positionXYZ = glm::vec3(3.0f, -3.8f, 2.0f);

	XrotationDegrees = 0;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.5f, 0.0f, 0.5f, 1.0f);
	//Notebook render texture 
	SetShaderTexture("notebook");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("notebook"); // Added shadermaterials august 2nd 


	m_basicMeshes->DrawBoxMesh();




	/******************************/
	/**********Mouse***********/
	//Render Mouse

	scaleXYZ = glm::vec3(.8f, 1.0f, -1.0f);
	positionXYZ = glm::vec3(.8f, -4.5f, 1.0f);

	XrotationDegrees = 0;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.5f, 0.0f, 0.5f, 1.0f);
	//Notebook render texture 
	SetShaderTexture("mouse");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("mouse"); // Added shadermaterials august 2nd 


	m_basicMeshes->DrawSphereMesh();





}
